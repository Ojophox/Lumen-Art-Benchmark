# LUMEN image pilot — upload guide

This package contains 12 renamed baseline images and the starter data files for `Lumen-Art-Benchmark`.

## Contents

- `images/SI_0001.jpg`–`SI_0012.jpg`
  - SI_0001–SI_0004: compositional intentionality
  - SI_0005–SI_0007: image consistency
  - SI_0008–SI_0012: visual storytelling
- `dataset/manifest.csv`: labels, briefs, tones, threats, categories, and provenance status
- `dataset/splits.json`: five calibration images and seven evaluation images
- `scores/scores_template.csv`: blank 0–3 review sheet for the 12 images

## Before publishing

The images were supplied as public-domain baselines. Artist/title/date entries in the manifest are **provisional**. Before a public release, verify each attribution and add the exact source-page URL to `source_url`. Do not publish any row whose provenance is unresolved.

## Upload with Git LFS

From your local clone of the repository:

```bash
git lfs install
git lfs track "*.jpg" "*.jpeg" "*.png" "*.webp"
git add .gitattributes
git commit -m "chore: enable Git LFS for images"
```

Unzip this package, then copy its folders into the repository root. Existing folders can be merged.

```bash
cp -R images dataset scores /path/to/Lumen-Art-Benchmark/
cd /path/to/Lumen-Art-Benchmark
git add .gitattributes images/ dataset/ scores/
git commit -m "feat: add 12-image LUMEN pilot set"
git push
```

After pushing, open several image files on GitHub to confirm that they display correctly.

## Review workflow

1. Fill in the rater name in `scores/scores_template.csv`.
2. Score the five calibration images first.
3. Re-score those five later without viewing the original scores.
4. Resolve rubric ambiguity before scoring the seven evaluation images.
5. Use integers 0–3. Use `NA` only when a dimension is explicitly not applicable.
6. Save the completed file as `scores/scores_v1.csv`; retain the blank template.
